'use strict';

var itemsCount = document.querySelector('.cart_amount'),
    burger = document.querySelector('.header_bars_small'),
    burgerOpened = false;

document.querySelector('#woman_catalog').onclick = setCatalog;
document.querySelector('#man_catalog').onclick = setCatalog;
document.querySelector('.cart_sum').textContent = localStorage.getItem('total') === null ? 0 : localStorage.getItem('total');

burger.onclick = function () {
    if (burgerOpened === false) {
        burger.setAttribute('class', 'header_bars_small active');
        burgerOpened = true;
    } else if (burgerOpened === true) {
        burger.setAttribute('class', 'header_bars_small');
        burgerOpened = false;
    }
};

var setCatalog = function setCatalog(event) {
    sessionStorage.removeItem('gender');

    if (event.target.id === 'woman_catalog') {
        sessionStorage.setItem('gender', 'women');
    } else {
        sessionStorage.setItem('gender', 'men');
    }
};

(function () {
    var shoppingBag = localStorage.getItem('shopping_bag'),
        items = JSON.parse(shoppingBag).length;
    itemsCount.textContent = items;
})();