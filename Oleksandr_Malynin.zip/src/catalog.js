document.querySelector('.cart_sum').textContent = JSON.parse(localStorage.getItem('total'));

let catalog             = JSON.parse(localStorage.getItem('catalog')),
	cromoCatalogWrapper = document.querySelector('.promo_block .catalog'),
	catalogWrapper      = document.querySelector('.main_catalog .catalog'),
	showMoreButton      = document.querySelector('#show_more'),
	categories          = [],
	state               = false;

for (let i = 0; i < 4; i++) {
    fillTheCatalog(catalog[i], cromoCatalogWrapper);
}

filter('fashion', 'not_selected');

function filter(nameKey, value) {
	switch (sessionStorage.getItem('gender')) {
		case 'women':
			for (let i = 0; i < (state ? catalog.length : 9); i++) {
				if (catalog[i].category === 'women' &&
				   (value === 'not_selected') ? true : catalog[i][nameKey] === value) {
					categories.push(catalog[i]);
				}
			}
			break;
		case 'men':
			for (let i = 0; i !== catalog.length; i++) {
				if (catalog[i].category === 'men') {
					categories.push(catalog[i]);
				}
			}
			break;
	}
	handleCatalogFill();
}

function handleCatalogFill() {
	for (let i = 0; i < categories.length; i++) {
		fillTheCatalog(categories[i], catalogWrapper);
	}
}

function fillTheCatalog(product, listTo) {
	let catalogCard 	= document.createElement('div'),
		productImage    = document.createElement('div'),
		productName     = document.createElement('div'),
		productPrice    = document.createElement('div'),
		img             = document.createElement('img'),
		a               = document.createElement('a');
	
	catalogCard.setAttribute('class', 'catalog_card');
	catalogCard.setAttribute('id', product.id);
	
	catalogCard.appendChild(productImage);
	productImage.setAttribute('class', 'product_image');
	productImage.appendChild(img);
	img.setAttribute('src', `img/${product.thumbnail}`);

	catalogCard.appendChild(productName);
	productName.setAttribute('class', 'product_name');
	productName.textContent = product.title;

	catalogCard.appendChild(productPrice);
	productPrice.setAttribute('class', 'product_price');
	productPrice.textContent = `£ ${+product.price}`;
	
	listTo.appendChild(a);
	a.appendChild(catalogCard);
	a.setAttribute('href', 'product.html');
	
	catalogCard.onclick = (event) => {
		localStorage.setItem('idActiveItem', event.target.parentNode.getAttribute('id'));
	};
}

let filterItem = document.querySelectorAll('.filter_select input'),
	filterType,
	filterValue;

function handleFilterChange(event) {
	filterType  = event.target.name;
	filterValue = event.target.value;

	let filterItem = document.querySelector('#' + event.target.name),
		filterSpan = document.querySelector('#' + event.target.name + ' span');

	event.target.value == 'not_selected' ?
		filterItem.setAttribute('class', 'filter_item')
		: filterItem.setAttribute('class', 'filter_item selected');

	filterSpan.textContent = event.target.parentNode.textContent;
	refresh(filterType,filterValue);
};

for (let i = 0; i < filterItem.length; i++) {
	filterItem[i].onchange = handleFilterChange;
}

/*=== show more ===*/

showMoreButton.onclick = () => {
	state = true;

	refresh();

	if (categories.length === catalogWrapper.children.length) {
		showMoreButton.style.display = "none";
	}
};

function refresh(filterType = 'fashion', filterValue = 'not_selected') {
	categories = [];
	while (catalogWrapper.children[0]) {
		catalogWrapper.removeChild(catalogWrapper.children[0]);
	}
	filter(filterType, filterValue);
}

/*=== filter ===*/

let filterDropdown  = document.querySelector('.adaptive_dropdown'),
	filterState     = false;

filterDropdown.onclick = () => {
	if (filterState === false) {
		filterDropdown.setAttribute('class', 'adaptive_dropdown active' );
		filterState = true;
	}
	else if ( filterState = true ) {
		filterDropdown.setAttribute('class', 'adaptive_dropdown' );
		filterState = false;
	}
}