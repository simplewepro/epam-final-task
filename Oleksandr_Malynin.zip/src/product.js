const catalogParsed = JSON.parse(localStorage.getItem('catalog'));
const idActiveItem      = localStorage.getItem('idActiveItem');

let activeProduct,
    submitItem;

for (let i = 0; i < catalogParsed.length; i++) {
    if (catalogParsed[i].id === idActiveItem) {
        activeProduct = catalogParsed[i];
    }
}

let mainImg  = document.querySelector(".main_image"),
    size     = document.querySelector(".thumbnails.size"),
    color    = document.querySelector(".thumbnails.color"),
    ul       = document.querySelector('.thumbnails_list'),
    addToBag = document.querySelector('.add_to_bag'),
    sizeArr  = activeProduct.sizes,
    colorArr = activeProduct.colors;

submitItem   = Object.assign( {} , activeProduct);

ul.onclick = (event) => {
    let newSrc = event.target.getAttribute('src');
    mainImg.firstElementChild.setAttribute('src', newSrc);
}

addToBag.onclick = () => {
    totalCostRefresh();
    let shoppingBag = localStorage.getItem('shopping_bag'),
        arr = JSON.parse(shoppingBag);
    arr.push(submitItem);
    localStorage.setItem('shopping_bag', JSON.stringify(arr));
    let sBag = localStorage.getItem('shopping_bag'),
        items = JSON.parse(sBag).length;
    itemsCount.textContent = items;
}

mainImg.firstElementChild.setAttribute('src', `img/${activeProduct.preview[0]}.png`);

for (let i = 0; i < sizeArr.length; i++) {
    filterSizes(sizeArr[i], i);
}

for (let i = 0; i < colorArr.length; i++) {
    filterColors(colorArr[i], i);
}


document.querySelector('.products_title').textContent = activeProduct.title;
document.querySelector('.product_description').textContent = activeProduct.description;
document.querySelector('.product_price').textContent = '£' + activeProduct.price;


for (let i = 0; i < activeProduct.preview.length; i++) {
    let li = document.createElement('li'),
        img = document.createElement('img');
    li.setAttribute('class', 'thumbnail_item');
    img.setAttribute('src', `img/${activeProduct.preview[i]}.png`);
    li.appendChild(img);
    ul.appendChild(li)
}


function filterSizes(item, iterator) {
    let label = document.createElement('label');
    label.setAttribute('for', `size_${iterator}`);
    let input = document.createElement('input');
    input.setAttribute('id', `size_${iterator}`);
    input.setAttribute('type', 'radio');
    input.setAttribute('name', 'image_thumb_size');
    input.setAttribute('value', item);
    input.addEventListener('click', function (event) {
        submitSize(event.target.value);
    })
    label.textContent = item;
    size.appendChild(input);
    size.appendChild(label)
}

function filterColors(item, iterator) {
    let label = document.createElement('label');
    label.setAttribute('for', `color_${iterator}`);
    let input = document.createElement('input');
    input.setAttribute('id', `color_${iterator}`);
    input.setAttribute('type', 'radio');
    input.setAttribute('name', 'image_thumb_color');
    input.setAttribute('value', item);
    input.addEventListener('click', function (event) {
        submitColor (event.target.value)
    })
    label.textContent = item;
    color.appendChild(input);
    color.appendChild(label)
}

function submitColor (value) {
    submitItem.colors= [];
    submitItem.colors.push(value);
}

function submitSize (value) {
    submitItem.sizes= [];
    submitItem.sizes.push(value);
}

function totalCostRefresh() {
    let total =  JSON.parse(localStorage.getItem('total'));
    document.querySelector('.cart_sum').textContent = (total += submitItem.price);
    localStorage.removeItem('total');
    localStorage.setItem('total', JSON.stringify(total));
}
